package com.capgemini.hms.main;

import com.capgemini.hms.dto.BookingDetails;
import com.capgemini.hms.service.IHotelService;

public class testmain {

	public static void main(String[] args)
	{
		IHotelService hotelService;
		
		BookingDetails book =new BookingDetails("101", "201", "111", "01-01-2017","03-01-2017", 2, 1, 2000.0);
		
		hotelService.addBookingDetails(book);
		
		
	}

}
